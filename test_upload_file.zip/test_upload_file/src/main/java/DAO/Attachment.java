package DAO;
import java.time.LocalDate;
import java.sql.Blob;
public class Attachment {
	private Long FileID;
	private String FileName;
	private Blob FileData;
	private String Description;
	public Long getFileID() {
		return FileID;
	}
	public void setFileID(Long iD) {
		this.FileID = iD;
	}
	public String getFileName() {
		return FileName;
	}
	public void setFileName(String FileName) {
		this.FileName = FileName;
	}
	public Blob getFileData() {
		return FileData;
	}
	public void setFileData(Blob FileData) {
		this.FileData = FileData;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String Description) {
		this.Description = Description;
	}
	
	public Attachment(Long FileID,String FileName, Blob FileData, String Description) {
		this.FileID = FileID;
		this.FileName = FileName;
		this.FileData = FileData;
		this.Description = Description;
	}
}
