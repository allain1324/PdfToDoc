package test_create_file.main;


//
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileReader;
import java.io.FileWriter;
public class ReadWritebyByte {
	public void ReadWritebyByteProcess()
	   {
		   try {
				File f = new File("C:\\Users\\toand\\Desktop\\BÀI-TẬP-THỰC-HÀNH-LẬP-TRÌNH-MẠNG_2.pdf");			
				FileInputStream fis = new FileInputStream(f);
				BufferedInputStream bis = new BufferedInputStream(fis);
				String fileName = "BÀI-TẬP-THỰC-HÀNH-LẬP-TRÌNH-MẠNG_2";
				File f1 = new File("C://Users/toand/Desktop//" + fileName + ".docx");
//				if (f1.createNewFile()) {
//	                System.out.println("File is created!");
//	            } else {
//	                System.out.println("File already exists.");
//	            }
				FileOutputStream fos = new FileOutputStream(f1);
				BufferedOutputStream bos = new BufferedOutputStream(fos);
				int c; 
				while((c = fis.read())!=-1){
					System.out.println(c);
					fos.write(c);
				}
				//InputStream is = new FileInputStream(f1);
				//this.writeToDB(conn, fileName, is, description);
			}catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
		   
	   }
	public void CreateFile() throws IOException
	{
		String fileName = "BÀI-TẬP-THỰC-HÀNH-LẬP-TRÌNH-MẠNG_2";
		File f1 = new File("C://Users/toand/Desktop//" + fileName + ".docx");
		if (f1.createNewFile()) {
            System.out.println("File is created!");
        } else {
            System.out.println("File already exists.");
        }
	}
	
	public ReadWritebyByte() {}
	public static void main(String[] args)
	{
		ReadWritebyByte temp = new ReadWritebyByte();
//		temp.ReadWritebyByteProcess();
		try
		{
//			temp.CreateFile();
			temp.ReadWritebyByteProcess();
		} catch (Exception e) {}
		
	}
}

//import java.io.BufferedInputStream;
//import java.io.BufferedOutputStream;
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.io.FileReader;
//import java.io.FileWriter;
//import java.io.InputStream;
//
//public class ReadWritebyByte {
//	public static void main(String[] args) {
//		try {
//			File f = new File("C:/Users/toand//Desktop/Hướng dẫn bài TH 1 - Phân tích tín hiệu nguyên âm_v1_2.pdf");			
//			FileInputStream fis = new FileInputStream(f);
//			BufferedInputStream bis = new BufferedInputStream(fis);
//			String fileName = "Hướng dẫn bài TH 1 - Phân tích tín hiệu nguyên âm_v1_2";
//			File f1 = new File("C:/Users/toand/Desktop/" + fileName + ".docx");
//			FileOutputStream fos = new FileOutputStream(f1);
//			BufferedOutputStream bos = new BufferedOutputStream(fos);
//			int c; 
//			while((c = fis.read())!=-1){
//				System.out.println(c);
//				fos.write(c);
//			}
//			System.out.println("ok");
//		}catch (Exception e) {
//			// TODO: handle exception
//			System.out.println(e);
//		}
//	}
//	public ReadWritebyByte() {}
//}
