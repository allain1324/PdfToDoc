package com.pdfoffice.pdftoword.pdftoword.config;

import org.springframework.stereotype.Component;

@Component
public class ServiceConfig {

}
